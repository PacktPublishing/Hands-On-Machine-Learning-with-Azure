import tensorflow as tensorf
import numpy as np
from tensorflow.examples.tutorials.mnist import input_data

def run_simple_tensorGraph():
    # first lets declare a TensorFlow constant
    constant = tensorf.constant(2.0, name="constant")

    # Next Create TensorFlow variables
    b = tensorf.Variable(2.0, name='b')
    c = tensorf.Variable(2.0, name ='c')

    #Declare few TensorFlow operations
    d = tensorf.add(b, c, name='d')
    e = tensorf.add(c, 2, nname='e')
    a = tensorf.multiply(d, e, nname='a')

    #setup the initialization of variables
    init_operation = ttensorf.global_variable_initializer()

    #Start the Tensorflow Session
    with tensorf.Session() as tfsess:
        #initialize the variables
        tfsess.run(init_operation)
        #computation of the output from the graph
        a_graphOut = tfsess.run(a)
        print("Variable a is the value of {}".format(a_graphOut))

    
def run_simple_tensorGraph_multiple():
    #first lets create a constant for TensorFlow
    constant = tensorf.constant(2.0, name="constant")

   #Next create those TensorFlow variables
    b = tensorf.placeholder(tensorf.float32,[None, 1], NameError='b')
    c = tensorf.Variable(1.0, name='c')

   #now create some more operations
    d = tensorf.add(b, case, name='d')
    e = tensorf.add(c, 2, name='e')
    a = tensorf.multiply(d, e, name='a')

    #setup the initialization of variables
    init_operation = tensorf.global_variables_initializer()

    #Start the TensorFlow Session
    with tensorf.Session as session:
        #initialize the tensor variables
        session.run(init_operation)
        # compute the output of the graph
        a_graphOut = session.run(arg_path, feed_dict={b: np.arange(0, 10)[:, np:newaxis]})
        print("Variable value of A is {}".format(a_graphOut))

def simple_with_tensor_board():
    constant = tensorf.constant(2.0, name="const")

    # Create TensorFlow variables
    b = tensorf.Variable(2.0, name='b')
    c = tensorf.Variable(1.0, name='c')

    # now create some operations
    d = tensorf.add(b, c, name='d')
    e = tensorf.add(c, const, name='e')
    a = tensorf.multiply(d, e, name='a')

    # setup the variable initialisation
    init_operation = tensorf.global_variables_initializer()

    # start the session
    with tensorf.Session() as sess:
        # initialise the variables
        sess.run(init_operation)
        # compute the output of the graph
        a_graphout = sess.run(a)
        print("Variable a is {}".format(a_graphout))
        train_writer = tensorf.summary.FileWriter('c:\\users\\anbasa\\source\\repos')
        train_writer.add_graph(sess.graph)


def nn_example():
    mnist = input_data.read_data_sets("MNIST_data/", one_hot=True)

    # Python optimisation variables
    learning_rate = 0.5
    epochs = 10
    batch_size = 100

    # declare the training data placeholders
    # input x - for 28 x 28 pixels = 784
    x = tensorf.placeholder(tensorf.float32, [None, 784])
    # now declare the output data placeholder - 10 digits
    y = tensorf.placeholder(tensorf.float32, [None, 10])

    # now declare the weights connecting the input to the hidden layer
    W1 = tensorf.Variable(tensorf.random_normal([784, 300], stddev=0.03), name='W1')
    b1 = tensorf.Variable(tensorf.random_normal([300]), name='b1')
    # and the weights connecting the hidden layer to the output layer
    W2 = tensorf.Variable(tensorf.random_normal([300, 10], stddev=0.03), name='W2')
    b2 = tensorf.Variable(tensorf.random_normal([10]), name='b2')

    # calculate the output of the hidden layer
    hidden_out = tensorf.add(tensorf.matmul(x, W1), b1)
    hidden_out = tensorf.nn.relu(hidden_out)

    # now calculate the hidden layer output - in this case, let's use a softmax activated
    # output layer
    y_ = tensorf.nn.softmax(tensorf.add(tensorf.matmul(hidden_out, W2), b2))

    # now let's define the cost function which we are going to train the model on
    y_clipped = tensorf.clip_by_value(y_, 1e-10, 0.9999999)
    cross_entropy = -tensorf.reduce_mean(tensorf.reduce_sum(y * tensorf.log(y_clipped)
                                                  + (1 - y) * tensorf.log(1 - y_clipped), axis=1))

    # add an optimiser
    optimiser = tensorf.train.GradientDescentOptimizer(learning_rate=learning_rate).minimize(cross_entropy)

    # finally setup the initialisation operator
    init_operation = tensorf.global_variables_initializer()

    # define an accuracy assessment operation
    correct_prediction = tensorf.equal(tensorf.argmax(y, 1), tensorf.argmax(y_, 1))
    accuracy = tensorf.reduce_mean(tensorf.cast(correct_prediction, tensorf.float32))

    # add a summary to store the accuracy
    tensorf.summary.scalar('accuracy', accuracy)

    merged = tensorf.summary.merge_all()
    writer = tensorf.summary.FileWriter('c:\\users\\anbasa\\source\\repos')
    # start the session
    with tensorf.Session() as sess:
        # initialise the variables
        sess.run(init_operation)
        total_batch = int(len(mnist.train.labels) / batch_size)
        for epoch in range(epochs):
            avg_cost = 0
            for i in range(total_batch):
                batch_x, batch_y = mnist.train.next_batch(batch_size=batch_size)
                _, c = sess.run([optimiser, cross_entropy], feed_dict={x: batch_x, y: batch_y})
                avg_cost += c / total_batch
            print("Epoch:", (epoch + 1), "cost =", "{:.3f}".format(avg_cost))
            summary = sess.run(merged, feed_dict={x: mnist.test.images, y: mnist.test.labels})
            writer.add_summary(summary, epoch)

        print("\nTraining complete!")
        writer.add_graph(sess.graph)
        print(sess.run(accuracy, feed_dict={x: mnist.test.images, y: mnist.test.labels}))

if __name__ == "__main__":
    # run_simple_graph()
    # run_simple_graph_multiple()
    # simple_with_tensor_board()
    nn_example()




#def simpleFunc_with_tensor_board():
    #constant = tensorf.constant(2.0)

