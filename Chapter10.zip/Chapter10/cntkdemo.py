# CNTK end to end sample demo
import os
import cntk as Cognitive
from cntk.train import Trainer
from cntk.io import MinibatchSource, CTFDeserializer, StreamDef, StreamDefs
from cntk.learners import adadelta, learning_rate_schedule, UnitType
from cntk.ops import relu, element_times, constant
from cntk.layers import Dense, Sequential, For, default_options
from cntk.losses import cross_entropy_with_softmax
from cntk.metrics import classification_error
from cntk.train.training_session import *
from cntk.logging import ProgressPrinter

input_dimension = 784
number_output_classes = 10
number_hidden_layers = 2
hidden_layers_dimension=200
feature_val = Cognitive.input_variable(input_dimension)
label_val = Cognitive.input_variable(number_output_classes)

def simple_mnist():
    input_dimension = 784
    number_output_classes = 10
    number_hidden_layers = 2
    hidden_layers_dimension = 200

# Instantiate the feedforward classification model
scaled_input = element_times(constant(0.00390625), feature_val)

with default_options(activation=relu, init=Cognitive.glorot_uniform()):
        z = Sequential([For(range(number_hidden_layers),
            lambda i: Dense(hidden_layers_dimension)),
            Dense(number_output_classes, activation=None)])(scaled_input)

ce = cross_entropy_with_softmax(z, label_val)
pe = classification_error(z, label_val)

# setup the data
#abs_path = os.path.dirname(os.path.abspath("C:\\Users\anbasa\Downloads\CNTK\Examples\Image\DataSets\MNIST"))
path =  "C:\\Users\\anbasa\\Downloads\\CNTK\\Examples\\Image\\DataSets\\MNIST\Train-28x28_cntk_text.txt"

reader_train_val = MinibatchSource(CTFDeserializer(path, StreamDefs(
        features=StreamDef(field='features', shape=input_dimension),
        labels=StreamDef(field='labels', shape=number_output_classes))))

input_map = {
        feature_val: reader_train_val.streams.features,
        label_val: reader_train_val.streams.labels
    }

# Training config
minibatch_size_val = 64
number_samples_per_sweep = 60000
number_sweeps_to_train_with = 10

# Instantiate progress writers.
progress_writers_val = [ProgressPrinter(
    tag='Training',
    num_epochs=number_sweeps_to_train_with)]

# Instantiate the trainer object to drive the model training
lr = learning_rate_schedule(1, UnitType.sample)
trainer = Trainer(z, (ce, pe), [adadelta(z.parameters, lr)], progress_writers_val)

training_session(
    trainer=trainer,
    mb_source=reader_train_val,
    mb_size=minibatch_size_val,
    model_inputs_to_streams=input_map,
    max_samples=number_samples_per_sweep * number_sweeps_to_train_with,
    progress_frequency=number_samples_per_sweep
).train()


# Load test data
path = "C:\\Users\\anbasa\\Downloads\\CNTK\\Examples\\Image\\DataSets\\MNIST\\Test-28x28_cntk_text.txt"

reader_test_val = MinibatchSource(CTFDeserializer(path, StreamDefs(
        features=StreamDef(field='features', shape=input_dimension),
        labels=StreamDef(field='labels', shape=number_output_classes))))

input_map = {
    feature_val: reader_test_val.streams.features,
    label_val: reader_test_val.streams.labels
}

# Test data for trained model
test_minibatch_size_val = 1024
num_samples = 10000
num_minibatches_to_test = num_samples / test_minibatch_size_val
test_result_cntk_final = 0.0
for i in range(0, int(num_minibatches_to_test)):
    mb = reader_test_val.next_minibatch(test_minibatch_size_val, input_map=input_map)
    eval_error = trainer.test_minibatch(mb)
    test_result_cntk_final = test_result_cntk_final + eval_error
   
# Average of evaluation errors of all test minibatches
#return test_result_cntk_final / num_minibatches_to_test	

#if __name__ == '__main__':
    #error = simple_mnist()
    #print("Error: %f" % error)